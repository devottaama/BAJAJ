
# Mutual Followers Spring Boot App

This Spring Boot application solves the **Bajaj Finserv Health Programming Challenge**.

## ✅ Features

- Auto-starts and POSTs to `/generateWebhook`
- Solves the **Mutual Followers** problem (for odd regNo)
- Sends result to dynamic webhook with **JWT Authorization**
- Retries 4 times on failure
- Uses `WebClient`, no REST controller

## 🚀 How to Run

```bash
mvn clean package
java -jar target/mutual-followers-0.0.1-SNAPSHOT.jar
```

## 📦 Submission Includes

- ✅ Full source code
- ✅ Final JAR
- ✅ Public GitHub Repo-ready structure

## 🧠 Problem Statement

From the `/generateWebhook` response, identify mutual followers:
> A and B follow each other → [min(A,B), max(A,B)]

## 🔗 Sample Output

```json
{
  "regNo": "REG12347",
  "outcome": [[1, 2], [3, 4]]
}
```
