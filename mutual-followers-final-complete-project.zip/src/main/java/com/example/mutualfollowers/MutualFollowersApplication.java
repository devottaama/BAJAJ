package com.example.mutualfollowers;

import com.example.mutualfollowers.service.WebhookService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MutualFollowersApplication {

    public static void main(String[] args) {
        SpringApplication.run(MutualFollowersApplication.class, args);
    }

    @Bean
    CommandLineRunner run(WebhookService service) {
        return args -> service.handleStartup();
    }
}