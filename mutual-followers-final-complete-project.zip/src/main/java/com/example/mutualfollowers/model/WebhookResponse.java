package com.example.mutualfollowers.model;

import java.util.List;
import java.util.Map;
import com.example.mutualfollowers.model.User;

public class WebhookResponse {
    public String webhook;
    public String accessToken;
    public Map<String, List<User>> data;
}