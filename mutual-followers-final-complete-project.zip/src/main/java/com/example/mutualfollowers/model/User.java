package com.example.mutualfollowers.model;

import java.util.List;

public class User {
    public int id;
    public String name;
    public List<Integer> follows;
}