package com.example.mutualfollowers.service;

import com.example.mutualfollowers.model.User;
import com.example.mutualfollowers.model.WebhookResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.*;

@Service
public class WebhookService {

    private final WebClient client = WebClient.builder().build();

    public void handleStartup() {
        String registerUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook";

        Map<String, String> request = Map.of(
                "name", "John Doe",
                "regNo", "REG12347",
                "email", "john@example.com"
        );

        WebhookResponse response = client.post()
                .uri(registerUrl)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(WebhookResponse.class)
                .block();

        if (response != null) {
            List<User> users = response.data.get("users");
            List<List<Integer>> mutualPairs = findMutualFollowers(users);
            sendToWebhook(response.webhook, response.accessToken, mutualPairs);
        }
    }

    private List<List<Integer>> findMutualFollowers(List<User> users) {
        Map<Integer, Set<Integer>> followsMap = new HashMap<>();
        for (User u : users) {
            followsMap.put(u.id, new HashSet<>(u.follows));
        }

        Set<String> seen = new HashSet<>();
        List<List<Integer>> result = new ArrayList<>();

        for (User u : users) {
            for (Integer followed : u.follows) {
                if (followsMap.containsKey(followed) && followsMap.get(followed).contains(u.id)) {
                    int a = Math.min(u.id, followed);
                    int b = Math.max(u.id, followed);
                    String key = a + "-" + b;
                    if (!seen.contains(key)) {
                        seen.add(key);
                        result.add(List.of(a, b));
                    }
                }
            }
        }
        return result;
    }

    private void sendToWebhook(String webhookUrl, String token, List<List<Integer>> outcome) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("regNo", "REG12347");
        payload.put("outcome", outcome);

        for (int i = 1; i <= 4; i++) {
            try {
                client.post()
                        .uri(webhookUrl)
                        .header("Authorization", token)
                        .header("Content-Type", "application/json")
                        .bodyValue(payload)
                        .retrieve()
                        .toBodilessEntity()
                        .block();
                System.out.println("Webhook success on attempt " + i);
                break;
            } catch (Exception e) {
                System.out.println("Attempt " + i + " failed: " + e.getMessage());
            }
        }
    }
}